import { Directive } from '@angular/core';

@Directive({
  selector: '[appAnimTransitionRevealSimple]'
})
export class AnimTransitionRevealSimpleDirective {

  constructor() { }

}
