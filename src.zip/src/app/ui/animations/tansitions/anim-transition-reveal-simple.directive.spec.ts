import { AnimTransitionRevealSimpleDirective } from './anim-transition-reveal-simple.directive';

describe('AnimTransitionRevealSimpleDirective', () => {
  it('should create an instance', () => {
    const directive = new AnimTransitionRevealSimpleDirective();
    expect(directive).toBeTruthy();
  });
});
