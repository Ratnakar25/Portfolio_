import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home.component';
import { HomeTopComponent } from './home-top/home-top.component';
import { HomeAboutComponent } from './home-about/home-about.component';
import { HomeExpertiseComponent } from './home-expertise/home-expertise.component';
import { HomeContactComponent } from './home-contact/home-contact.component';
import { HomeShowcasesComponent } from './home-showcases/home-showcases.component';

const routes: Routes = [
  {
    path: "",
    component: HomeComponent
  },
  {path:'home',component:HomeTopComponent},
  {path:'about',component:HomeAboutComponent},
  {path:'expertise',component:HomeExpertiseComponent},
  {path:'contact',component:HomeContactComponent},
  {path:'showcase',component:HomeShowcasesComponent},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
