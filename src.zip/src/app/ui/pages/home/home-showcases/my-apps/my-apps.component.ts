import { ScrollDispatcher, ViewportRuler } from '@angular/cdk/scrolling';
import { ChangeDetectorRef, Component, ElementRef, NgZone, OnInit, ViewChild } from '@angular/core';
import { MediaObserver } from '@angular/flex-layout';
import { FormBuilder } from '@angular/forms';
import { ReplaySubject, takeUntil, startWith, map, scan, distinctUntilChanged, takeWhile, switchMap, Observable } from 'rxjs';
import { AppType } from 'src/app/types/apps_type';
import { TRANSITION_IMAGE_SCALE, TRANSITION_TEXT } from 'src/app/ui/animations/transitions/transitions.constants';
import { UiUtilsView } from 'src/app/ui/utils/views.utils';

@Component({
  selector: 'app-my-apps',
  templateUrl: './my-apps.component.html',
  styleUrls: ['./my-apps.component.scss'],
  animations: [
    TRANSITION_TEXT,
    TRANSITION_IMAGE_SCALE
  ]
})
export class MyAppsComponent implements OnInit {


  _mApps : AppType[] = [

    {
     "id": "5131",
     "name": "SumZ : Article summarizer",
     "image": "assets/img/apps/sumz2.png",
     "link": "https://articlesumz.onrender.com/",
     "tab": "TypeScript",
     "caption": "Tool that converts lengthy articles into concise, easy-to-read summaries to help save time by summarizing long articles using RapidAPI.",
     "isFull": false,
     "primary":"#3FD67D",
     "background":"#E1E1E1"
   },
   {
     "id": "5132",
     "name": "Voyager : Travel Booking website",
     "image": "assets/img/apps/voyager1.png",
     "link": "https://main.d21xs211rxomry.amplifyapp.com",
     "tab": "ReactJS",
     "isFull": false,
     "caption": "A travel website made using ReactJS is a dynamic and responsive web application. By integrating a weather API, the website can also display real-time weather updates for the chosen destination, allowing users to plan their trip accordingly.",
     "background":"#F5E7B4"
   },
   {
     "id": "5133",
     "name": "ChatHub : Chat messenger application",
     "image": "assets/img/apps/chathub2.png",
     "link": "https://github.com/Ratnakar25/ChatHub",
     "tab": "Android",
     "caption": "A Chat messenger application has been created using ReactJS (Chakra UI) for the frontend, NodeJS and ExpressJS for the backend, and MongoDB for the database. The application leverages Socket.io to establish real-time connections between users, facilitating both one-on-one and group chats.",
     "isFull": true,
     "background":"#3CE79F"
   }
  ];

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  mOnceAnimated = false

  /* ********************************************************************************************
    *                anims
    */
  _mTriggerAnim?= 'false'



  _mThreshold = 0.4


  @ViewChild('animRefView') vAnimRefView?: ElementRef<HTMLElement>;

  constructor(public el: ElementRef,
    private _ngZone: NgZone,
    private cdr: ChangeDetectorRef,
    public mediaObserver: MediaObserver,
    private scroll: ScrollDispatcher, private viewPortRuler: ViewportRuler,
    private formBuilder: FormBuilder) {



  }

  ngOnInit(): void {
  }



  ngAfterViewInit(): void {
    this.setupAnimation();
  }

  ngOnDestroy(): void {

    this.destroyed$.next(true)
    this.destroyed$.complete()
  }




  /* ***************************************************************************
   *                                  other parts
   */


  public setupAnimation() {

    // console.info("home products setupAnimation: " )
    
      


      // console.log("home-item setupAnimation ancestorScrolled: ", val)

      

      
        // console.log("HomeProductsComponent setupAnimation setupAnimation ancestorScrolled: ", val)

        this.mOnceAnimated = true
        this._mTriggerAnim = 'true'
        this.cdr.detectChanges()
      
      // if (this.vImageArea != null) {
      //   var visibility = UiUtilsView.getVisibility(this.vImageArea, this.viewPortRuler)
      //   console.log("UiUtilsView visibility: ", visibility)
      // }
    }

    
}
