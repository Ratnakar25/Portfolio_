import { ScrollDispatcher, ViewportRuler } from '@angular/cdk/scrolling';
import { ChangeDetectorRef, Component, ElementRef, NgZone, OnInit, ViewChild } from '@angular/core';
import { MediaObserver } from '@angular/flex-layout';
import { ReplaySubject, takeUntil, startWith, map, scan, distinctUntilChanged, takeWhile, switchMap, Observable } from 'rxjs';
import { TRANSITION_IMAGE_SCALE, TRANSITION_TEXT } from 'src/app/ui/animations/transitions/transitions.constants';
import { UiUtilsView } from 'src/app/ui/utils/views.utils';
import { FooterComponent } from 'src/app/ui/common/footer/footer.component';

@Component({
  selector: 'app-home-expertise',
  templateUrl: './home-expertise.component.html',
  styleUrls: ['./home-expertise.component.scss'],
  animations: [
    TRANSITION_TEXT,
    TRANSITION_IMAGE_SCALE,
    TRANSITION_TEXT,
  ]
})
export class HomeExpertiseComponent implements OnInit {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  mOnceAnimated = false

  /* ********************************************************************************************
    *                anims
    */
  _mTriggerAnim?= 'false'

  _mTriggerImage?= 'false'


  _mThreshold = 0.2


  @ViewChild('animRefView') vAnimRefView?: ElementRef<HTMLElement>;

  constructor(public el: ElementRef,
    private _ngZone: NgZone,
    private cdr: ChangeDetectorRef,
    public mediaObserver: MediaObserver,
    private scroll: ScrollDispatcher, private viewPortRuler: ViewportRuler) { }

  ngOnInit(): void {
  }



  ngAfterViewInit(): void {
    this.setupAnimation();
  }

  ngOnDestroy(): void {

    this.destroyed$.next(true)
    this.destroyed$.complete()
  }


  public setupAnimation() {
   

    // console.info("home products setupAnimation: " )
    
      


      // console.log("home-item setupAnimation ancestorScrolled: ", val)

      

      
        // console.log("HomeProductsComponent setupAnimation setupAnimation ancestorScrolled: ", val)

        this.mOnceAnimated = true
        this._mTriggerAnim = 'true'
        this.cdr.detectChanges()
      
      // if (this.vImageArea != null) {
      //   var visibility = UiUtilsView.getVisibility(this.vImageArea, this.viewPortRuler)
      //   console.log("UiUtilsView visibility: ", visibility)
      // }
    

    
  }

  _mTools = [

    // design
    
    {
      "id": "8101",
      "name": "Angular",
      "logo": "assets/img/tools/angular.png",
      "link": "https://angular.io/",
      "tab": "web",
      "color": "#FF4369"
    },
    {
      "id": "8102",
      "name": "C++",
      "logo": "assets/img/tools/cpp.png",
      "link": "https://www.cplusplus.com/",
      "tab": "programming",
      "color": "#00599C"
    },
    {
      "id": "8103",
      "name": "Java",
      "logo": "assets/img/tools/java.png",
      "link": "https://www.oracle.com/java/",
      "tab": "programming",
      "color": "lightgrey"
    },
    {
      "id": "8104",
      "name": "HTML5",
      "logo": "assets/img/tools/html5.png",
      "link": "https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/HTML5",
      "tab": "web",
      "color": "#E34F26"
    },
    {
      "id": "8105",
      "name": "CSS3",
      "logo": "assets/img/tools/css3.png",
      "link": "https://developer.mozilla.org/en-US/docs/Web/CSS",
      "tab": "web",
      "color": "#264de4"
    },
    {
      "id": "8106",
      "name": "Bootstrap",
      "logo": "assets/img/tools/bootstrap.png",
      "link": "https://getbootstrap.com/",
      "tab": "web",
      "color": "#563D7C"
    },
    {
      "id": "8107",
      "name": "Python",
      "logo": "assets/img/tools/python.png",
      "link": "https://www.python.org/",
      "tab": "programming",
      "color": "#3776AB"
    },
    {
      "id": "8108",
      "name": "MongoDB",
      "logo": "assets/img/tools/mongodb.jpg",
      "link": "https://www.mongodb.com/",
      "tab": "database",
      "color": "#47A248"
    },
    {
      "id": "8109",
      "name": "JavaScript",
      "logo": "assets/img/tools/javascript.png",
      "link": "https://developer.mozilla.org/en-US/docs/Web/JavaScript",
      "tab": "web",
      "color": "#F7DF1E"
    },
    {
      "id": "8110",
      "name": "SQL",
      "logo": "assets/img/tools/sql.png",
      "link": "https://www.sql.org/",
      "tab": "database",
      "color": "#00758F"
    },
    // web
    {
      "id": "5131",
      "name": "Figma",
      "logo": "assets/img/tools/figma.svg",
      "link": "https://www.figma.com/",
      "tab": "design"
    },
    

    {
      "id": "5132",
      "name": "Adobe Photoshop",
      "logo": "assets/img/tools/ps.png",
      "link": "https://www.adobe.com/products/photoshop.html",
      "tab": "design"
    },

    // cross
{
      "id": "4101",
      "name": "Flutter",
      "logo": "assets/img/tools/flutter_logo.svg",
      "link": "https://flutter.dev/",
      "tab": "Cross",
      "color": "#42A5F5"
    },
    

   

    
    
    
    {
      "id": "8103",
      "name": "Sass",
      "logo": "assets/img/tools/sass-logo.svg",
      "link": "https://sass-lang.com/",
      "tab": "web",
      "color": "#CF649A"
    },

    
    
   
    

    // backend

    {
      "id": "7121",
      "name": "Express",
      "logo": "assets/img/tools/express.png",
      "link": "https://expressjs.com/",
      "tab": "back-end"
    },
    

    {
      "id": "7126",
      "name": "NodeJs",
      "logo": "assets/img/tools/nodejs.png",
      "link": "https://nodejs.org/en/",
      "tab": "back-end"
    },

    // cloud

    

    {
      "id": "6123",
      "name": "Azure",
      "logo": "assets/img/tools/azure.png",
      "link": "https://azure.microsoft.com",
      "tab": "cloud"
    },

    


  ]

}
