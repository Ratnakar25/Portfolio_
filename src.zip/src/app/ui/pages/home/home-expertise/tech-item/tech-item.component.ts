import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tech-item',
  templateUrl: './tech-item.component.html',
  styleUrls: ['./tech-item.component.scss']
})
export class TechItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
