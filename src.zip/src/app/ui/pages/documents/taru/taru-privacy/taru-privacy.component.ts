import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-taru-privacy',
  templateUrl: './taru-privacy.component.html',
  styleUrls: ['./taru-privacy.component.scss']
})
export class TaruPrivacyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
