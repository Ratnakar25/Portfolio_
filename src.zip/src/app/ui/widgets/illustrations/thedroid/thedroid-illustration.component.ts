import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thedroid-illustration',
  templateUrl: './thedroid-illustration.component.html',
  styleUrls: ['./thedroid-illustration.component.scss']
})
export class ThedroidIllustrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
