import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-junkielabs-illustration',
  templateUrl: './junkielabs-illustration.component.html',
  styleUrls: ['./junkielabs-illustration.component.scss']
})
export class JunkielabsIllustrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
