import { WidgetWaterfallDirective } from './widget-waterfall.directive';

describe('WidgetWaterfallDirective', () => {
  it('should create an instance', () => {
    const directive = new WidgetWaterfallDirective();
    expect(directive).toBeTruthy();
  });
});
