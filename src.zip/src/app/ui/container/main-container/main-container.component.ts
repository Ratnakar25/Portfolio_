import { Platform } from '@angular/cdk/platform';
import { Component, ElementRef, NgZone, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { fromEvent, Subscription } from 'rxjs';
import { ScrollEventService } from 'src/app/core/scroll/scroll-event.service';
import { ENTER_FORM_TOP, TRANSITION_REVEAL } from '../../animations/transitions/transitions.constants';
import { HomeAboutComponent } from '../../pages/home/home-about/home-about.component';
import { ScrollDispatcher, ViewportRuler } from '@angular/cdk/scrolling';
import { ChangeDetectorRef,} from '@angular/core';
import { MediaObserver } from '@angular/flex-layout';
import { takeUntil, startWith, map, scan, distinctUntilChanged, takeWhile, switchMap, Observable, ReplaySubject } from 'rxjs';
import { ENTER_SCALE, TRANSITION_AREA_SLIDE, TRANSITION_IMAGE_SCALE, TRANSITION_TEXT } from 'src/app/ui/animations/transitions/transitions.constants';
import { UiUtilsView } from 'src/app/ui/utils/views.utils';
import { FooterComponent } from 'src/app/ui/common/footer/footer.component';
@Component({
  selector: 'app-main-container',
  templateUrl: './main-container.component.html',
  styleUrls: ['./main-container.component.scss'],
  animations:[
    ENTER_FORM_TOP,TRANSITION_REVEAL,
  
      TRANSITION_TEXT,
      TRANSITION_AREA_SLIDE,
      TRANSITION_IMAGE_SCALE,
      ENTER_SCALE
    
  ]
})
export class MainContainerComponent implements OnInit {


  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  mOnceAnimated = false
  
  /* ********************************************************************************************
  *                anims
  */
  _mTriggerAnim?= 'false'
  
  _mTriggerImage?= 'false'
  
  
  _mThreshold = 0.2
    private _scrollTargetSubscription: Subscription | null = null;
    @ViewChild('animRefView') vAnimRefView?: ElementRef<HTMLElement>;
    @ViewChild('contentScroller') vContentScroller?: ElementRef<HTMLElement>;

    constructor(public el: ElementRef,
      private _ngZone: NgZone,
      private cdr: ChangeDetectorRef,
      public mediaObserver: MediaObserver,
      private scroll: ScrollDispatcher, private viewPortRuler: ViewportRuler) { }
   
   
    

    
    
  
    ngOnInit(): void {
    }
    ngAfterViewInit(): void {
      //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
      this._initScrollHandler();    
      // this._scrollService.dispatchUpdate(this.vContentScroller);
      this.setupAnimation();
      
    }
    
    
  
    ngOnDestroy(): void {
      //Called once, before the instance is destroyed.
      //Add 'implements OnDestroy' to the class.
      this.destroyed$.next(true)
  this.destroyed$.complete()
      // this._scrollService.dispatchUpdate(undefined);
    }
  
    
  
    private _initScrollHandler(): void {
      if (this._scrollTargetSubscription) {
        this._scrollTargetSubscription.unsubscribe();
      }
      // if (!this._platform.isBrowser) {
      //   return;
      // }
  
      // console.log("suscribed");
  
  
      this._scrollTargetSubscription = this._ngZone.runOutsideAngular(() =>
        fromEvent<Event>(this.vContentScroller?.nativeElement || window, 'scroll')
          .subscribe((event) => this._ngZone.run(() => {
            // console.log("suscribed event");
            // this._scrollService.emitActionMainEvent(event);
            
          })));
    }
    _scrollToElement(id: string): void {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
      }
   }
  
  
    // legacyKey: string
    _openNavigation() {
      // let dialogRef = this.dialog.open(NavigationMainComponent, {
      //   width: '100vw',
      //   height: '100vh',
      //   maxWidth: '100vw',
      //   maxHeight: '100vh',
      //   hasBackdrop: true,
      //   panelClass: "dialog-translucent",
      //   backdropClass: "tb-color-bg--black-75",
      //   data: {
      //     stage: "design",
      //     // name: legacyKey
      //   },
      // });
    }
  
    _onToolbarAnimationEnd($event: any){
  
      // console.info("_onToolbarAnimationEnd: ", $event)
  
    }
    public setupAnimation() {
  
      this.mOnceAnimated = true
      this._mTriggerAnim = 'true'
      this.cdr.detectChanges()
    
    // if (this.vImageArea != null) {
    //   var visibility = UiUtilsView.getVisibility(this.vImageArea, this.viewPortRuler)
    //   console.log("UiUtilsView visibility: ", visibility)
    // }
  }


} 











  


