export class DialogModelProgress {
  constructor(
    public title: string,
    public message: string,
    public key?: any,
    public dialogType?: string
  ) {}
}
