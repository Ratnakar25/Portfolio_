export const environment = {
  production: true,
  apiUrl: 'https://us-central1-junkielabs-57977.cloudfunctions.net/apiPortfolio',
  recaptcha: '6Lci95YiAAAAAOfkpaWwNSHiX5Ye7KT9ZOw-HYCv'
};
